# EfficientMixNets
Some work around EfficientNet, MixNets and Attentive Normalization
